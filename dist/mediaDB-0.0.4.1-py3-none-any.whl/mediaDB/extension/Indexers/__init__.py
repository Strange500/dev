from mediaDB.extension.Indexers.nyaa import Nyaa_manipulator
from mediaDB.extension.Indexers.common import IndexerCommon