from mediaDB.common import *
from mediaDB.settings import *




class Database():
    ...
    
