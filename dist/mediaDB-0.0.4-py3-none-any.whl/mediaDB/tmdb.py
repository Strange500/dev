result = {
            "adult": None,
            "first_air_date": None,
            "last_air_date": None,
            "genres": None,
            "tmdb_id": None,
            "in_production": None,
            "last_episode_to_air": {
                "air_date" : None,
                "episode_number": None,
                "season_number": None
            },
            "title": None,
            "other_titles": None,
            "next_episode_to_air": {
                "air_date" : None,
                "episode_number": None,
                "season_number": None
            },
            "number_of_episodes": None,
            "number_of_season": None,
            "original_language": None,
            "seasons": [
                {
                    "air_date": None,
                    "episode_count": None,
                    "name": None,
                    "season_number": None
                }],
            "status": None,

        }